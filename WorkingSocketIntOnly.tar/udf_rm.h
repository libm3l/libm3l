#ifndef  __FREE_H__
#define __FREE_H__

int Free(node_t **);

#endif

#ifndef  __ALLOCATE_H__
#define __ALLOCATE_H__

int Allocate(node_t **, tmpstruct_t );

#endif

#ifndef  __ALLOCATE_NODE_H__
#define __ALLOCATE_NODE_H__

node_t *AllocateNode(tmpstruct_t);

#endif
