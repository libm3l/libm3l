#ifndef  __MOUNT_H__
#define __MOUNT_H__

node_t *Mount(const char *);

#endif


#ifndef __UMOUNT_H__
#define __UMOUNT_H__

int Umount(node_t **);

#endif
