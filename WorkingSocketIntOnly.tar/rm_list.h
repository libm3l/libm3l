#ifndef __RM_LIST_H__
#define __RM_LIST_H__

SIZE_T rm_list(int , node_t **);

#endif
