#ifndef __RM_H__
#define __RM_H__

size_t Rm(node_t **, char * , ...);

#endif
