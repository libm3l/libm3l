#ifndef  __ADD_LIST_H__
#define __ADD_LIST_H__

int add_list(node_t **, node_t **, char );

#endif
