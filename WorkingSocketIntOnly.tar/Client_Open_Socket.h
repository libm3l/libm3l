#ifndef __CLI_OPEN_SOCKET_H__
#define __CLI_OPEN_SOCKET_H__

int cli_open_socket(const char *, int);

#endif
