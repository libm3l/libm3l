#ifndef __READDIR_H__
#define __READDIR_H__

node_t *ReadDir(FILE *);

#endif

#ifndef __READDIRDATA_H__
#define __READDIRDATA_H__

node_t *ReadDirData(tmpstruct_t, FILE *);

#endif
