#ifndef __FREAD_H__
#define __FREAD_H__

node_t *Fread(const char *);

#endif
