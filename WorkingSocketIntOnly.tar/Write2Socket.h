#ifndef __WRITE_TO_SOCKET_H__
#define __WRITE_TO_SOCKET_H__

int write_to_socket(int , node_t *,  int );

#endif
