#ifndef __CLI_OPEN_SOCKET_H__
#define __CLI_OPEN_SOCKET_H__

int openbindlistensocket(int );

#endif
