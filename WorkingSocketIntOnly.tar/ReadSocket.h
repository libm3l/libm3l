#ifndef __READSOCKET_H__
#define __READSOCKET_H__

node_t *read_socket(int);

#endif