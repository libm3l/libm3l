#ifndef __READDATA_H__
#define __READDATA_H__

node_t *ReadData(FILE *);

#endif
