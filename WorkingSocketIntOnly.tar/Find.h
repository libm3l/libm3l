#ifndef __FIND_LIST_POINTER_H__
#define __FIND_LIST_POINTER_H__

find_t **Find(node_t *, size_t *, char * , ...);

#endif
