#ifndef __READDESCRIPTOR_H__
#define __READDESCRIPTOR_H__

node_t *read_file(FILE *);

#endif