#ifndef  __FIND_CALLER_H__
#define  __FIND_CALLER_H__

find_t **Find_caller(node_t *, size_t *, char *, opts_t *);

#endif

#ifndef  __DESTROYFOUND_H__
#define  __DESTROYFOUND_H__

void DestroyFound(find_t **, size_t );

#endif
