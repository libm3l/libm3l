#ifndef __WRITEDATA_H__
#define __WRITEDATA_H__

int WriteData(node_t *, FILE *);

#endif
