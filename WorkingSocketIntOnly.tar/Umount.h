#ifndef __UMOUNT_H__
#define __UMOUNT_H__

int Umount(node_t **)

#endif
