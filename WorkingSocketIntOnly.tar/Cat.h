#ifndef __CAT_H__
#define __CAT_H__

int Cat(node_t *, char * , ...);

#endif
